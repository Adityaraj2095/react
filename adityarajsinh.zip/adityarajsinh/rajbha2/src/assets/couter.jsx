import { useState } from "react";
import "../index.css";

function Counter() {
  const [hobbies, setHobbies] = useState([]);
  const [gender, setGender] = useState("");

  const handleHobbyChange = (event) => {
    const { value, checked } = event.target;

    if (checked) {
      setHobbies([...hobbies, value]);
    } else {
      setHobbies(hobbies.filter((hobby) => hobby !== value));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const formData = {
      gender: gender,
      hobbies: hobbies,
    };

    console.log("Form Submitted");
    console.log("Gender:", gender);
    console.log("Hobbies:", hobbies);
    console.log("Complete Form Data:", formData);

    alert("Form submitted successfully!");
  };

  return (
    <div className="container">
      <h1>Student Form</h1>

      <form onSubmit={handleSubmit}>
        {/* Checkboxes */}
        <div className="form-section">
          <h2>Select Your Hobbies</h2>

          <label>
            <input
              type="checkbox"
              value="Cricket"
              checked={hobbies.includes("Cricket")}
              onChange={handleHobbyChange}
            />
            Cricket
          </label>

          <label>
            <input
              type="checkbox"
              value="Singing"
              checked={hobbies.includes("Singing")}
              onChange={handleHobbyChange}
            />
            Singing
          </label>

          <label>
            <input
              type="checkbox"
              value="Dancing"
              checked={hobbies.includes("Dancing")}
              onChange={handleHobbyChange}
            />
            Dancing
          </label>
        </div>

        {/* Radio Buttons */}
        <div className="form-section">
          <h2>Select Gender</h2>

          <label>
            <input
              type="radio"
              name="gender"
              value="Male"
              checked={gender === "Male"}
              onChange={(e) => setGender(e.target.value)}
            />
            Male
          </label>

          <label>
            <input
              type="radio"
              name="gender"
              value="Female"
              checked={gender === "Female"}
              onChange={(e) => setGender(e.target.value)}
            />
            Female
          </label>

          <label>
            <input
              type="radio"
              name="gender"
              value="Other"
              checked={gender === "Other"}
              onChange={(e) => setGender(e.target.value)}
            />
            Other
          </label>
        </div>

        {/* Submit Button */}
        <button type="submit" className="submit-btn">
          Submit
        </button>
      </form>

      {/* Output */}
      <div className="output">
        <h2>Output</h2>

        <p>
          <strong>Gender:</strong>{" "}
          {gender || "Not selected"}
        </p>

        <p>
          <strong>Hobbies:</strong>{" "}
          {hobbies.length > 0
            ? hobbies.join(", ")
            : "No hobby selected"}
        </p>
      </div>
    </div>
  );
}

export default Counter;
