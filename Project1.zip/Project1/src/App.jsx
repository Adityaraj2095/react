import { useState, createContext, useContext } from 'react';
import { Routes, Route, NavLink } from 'react-router-dom';
import App1 from './App1.jsx';
import Login from './Login.jsx';
import UseRefDemo from './UseRefDemo.jsx';
import CricketScoreboard from './CricketScoreboard.jsx';
import './App.css';

const MyContext = createContext(null);

function Comp1() {
  const { setData } = useContext(MyContext);
  return <button className="primary-btn" onClick={() => setData('From Context')}>Set Data</button>;
}

function Comp2() {
  const { data } = useContext(MyContext);
  return <p className="context-value">Current value: <strong>{data}</strong></p>;
}

function ContextDemo() {
  const [data, setData] = useState('MCA');
  return (
    <section className="panel context-panel">
      <div className="eyebrow">REACT FUNDAMENTALS</div>
      <h1>Context API Demo</h1>
      <p className="panel-description">Share data between components without passing props manually.</p>
      <MyContext.Provider value={{ data, setData }}>
        <div className="context-content">
          <Comp2 />
          <Comp1 />
        </div>
      </MyContext.Provider>
    </section>
  );
}

function App() {
  return (
    <main className="site-shell">
      <header className="site-header">
        <div className="brand"><span className="brand-mark">R</span><div><strong>React Studio</strong><small>Learning dashboard</small></div></div>
        <nav className="site-nav" aria-label="Main navigation">
          <NavLink to="/login" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Login</NavLink>
          <NavLink to="/tasks" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Task Manager</NavLink>
          <NavLink to="/context" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Context API</NavLink>
          <NavLink to="/useref" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>useRef</NavLink>
          <NavLink to="/cricket" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Cricket Score</NavLink>
        </nav>
      </header>
      <div className="page-content">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/tasks" element={<App1 />} />
          <Route path="/context" element={<ContextDemo />} />
          <Route path="/useref" element={<UseRefDemo />} />
          <Route path="/cricket" element={<CricketScoreboard />} />
          <Route path="*" element={<section className="panel not-found"><h1>Page not found</h1><p>The page you are looking for doesn't exist.</p><NavLink className="primary-btn link-button" to="/">Back to home</NavLink></section>} />
        </Routes>
      </div>
      <footer className="site-footer">Practical Assignment 2 <span>•</span> React Hooks &amp; Routing</footer>
    </main>
  );
}

export default App;
