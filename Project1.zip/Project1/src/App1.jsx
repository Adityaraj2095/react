import { useState } from 'react';
import './App.css';

function App1() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);

  const handleClick = () => {
    const trimmedTask = task.trim();
    if (!trimmedTask) return;
    setTasks((currentTasks) => [...currentTasks, { id: `${Date.now()}-${Math.random()}`, text: trimmedTask, completed: false }]);
    setTask('');
  };

  const toggleTask = (id) => {
    setTasks((currentTasks) => currentTasks.map((item) => item.id === id ? { ...item, completed: !item.completed } : item));
  };
  const completedCount = tasks.filter((item) => item.completed).length;
  const handleSubmit = (event) => { event.preventDefault(); handleClick(); };

  return (
    <section className="panel task-panel">
      <div className="eyebrow">STAY ORGANIZED</div>
      <h1>Task Manager</h1>
      <p className="panel-description">Add your tasks, check them off, and keep track of your progress.</p>

      <form className="task-form" onSubmit={handleSubmit}>
        <label htmlFor="task-input">What needs to get done?</label>
        <div className="input-row">
          <input id="task-input" className="task-input" type="text" placeholder="e.g. Complete React assignment" value={task} onChange={(event) => setTask(event.target.value)} />
          <button className="primary-btn add-btn" type="submit">+ Add task</button>
        </div>
      </form>

      <div className="list-heading"><h2>Your tasks</h2><span className="task-count">{tasks.length} total</span></div>
      {tasks.length === 0 ? (
        <div className="empty-state"><span className="empty-icon">✓</span><strong>You're all caught up</strong><p>Add a task above to get started.</p></div>
      ) : (
        <ul className="task-list">
          {tasks.map((item) => (
            <li className={`task-item${item.completed ? ' completed' : ''}`} key={item.id}>
              <label className="task-label">
                <input className="task-checkbox" type="checkbox" checked={item.completed} onChange={() => toggleTask(item.id)} />
                <span className="custom-check" aria-hidden="true">✓</span>
                <span className="task-text">{item.text}</span>
              </label>
              <span className={`status-pill${item.completed ? ' done' : ''}`}>{item.completed ? 'Completed' : 'In progress'}</span>
            </li>
          ))}
        </ul>
      )}

      <div className="progress-card">
        <div className="progress-copy"><span>Completion progress</span><strong>{tasks.length ? Math.round((completedCount / tasks.length) * 100) : 0}%</strong></div>
        <div className="progress-track"><div className="progress-fill" style={{ width: `${tasks.length ? (completedCount / tasks.length) * 100 : 0}%` }} /></div>
        <p>{completedCount} of {tasks.length} {tasks.length === 1 ? 'task' : 'tasks'} completed</p>
      </div>
    </section>
  );
}

export default App1;
