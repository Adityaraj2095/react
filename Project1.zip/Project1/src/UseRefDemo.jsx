import { useRef, useState } from 'react';
import './App.css';

export default function UseRefDemo() {
  const inputRef = useRef(null);
  const renderCount = useRef(0);
  const [text, setText] = useState('');
  renderCount.current += 1;

  const focusInput = () => inputRef.current?.focus();
  const clearInput = () => {
    setText('');
    inputRef.current?.focus();
  };

  return <section className="panel practical-panel">
    <div className="eyebrow">PRACTICAL 04 · REACT HOOKS</div>
    <h1>useRef Hook</h1>
    <p className="panel-description">Use a ref to focus an input and retain a mutable value between renders.</p>
    <div className="demo-box">
      <label htmlFor="ref-input">Type something</label>
      <input ref={inputRef} id="ref-input" className="task-input" value={text} onChange={e => setText(e.target.value)} placeholder="Click Focus input, then type…" />
      <div className="button-row">
        <button className="primary-btn" onClick={focusInput} type="button">Focus input</button>
        <button className="secondary-btn" onClick={clearInput} type="button">Clear input</button>
      </div>
    </div>
    <div className="ref-stats"><span>Current input value</span><strong>{text || '—'}</strong><span>Render count (stored in useRef)</span><strong>{renderCount.current}</strong></div>
    <p className="helper-note">Updating a ref does not itself trigger a re-render. The count shown updates when another state change renders the component.</p>
  </section>;
}
