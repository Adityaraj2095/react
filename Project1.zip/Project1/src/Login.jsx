import { useState } from 'react';
import './App.css';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [signedIn, setSignedIn] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    if (!email.trim() || !password.trim()) {
      setMessage('Please enter both email and password.');
      return;
    }
    setSignedIn(true);
    setMessage(`Demo login successful for ${email}. This practical does not use a backend.`);
  }

  return <section className="panel practical-panel">
    <div className="eyebrow">PRACTICAL 01 · FORMS & STATE</div>
    <h1>{signedIn ? 'Welcome!' : 'Login Application'}</h1>
    <p className="panel-description">A simple login form using React useState and form handling.</p>
    <form className="practical-form" onSubmit={handleSubmit}>
      <label htmlFor="login-email">Email address</label>
      <input id="login-email" className="task-input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
      <label htmlFor="login-password">Password</label>
      <input id="login-password" className="task-input" type="password" placeholder="Enter password" value={password} onChange={e => setPassword(e.target.value)} required />
      <button className="primary-btn" type="submit">{signedIn ? 'Sign in again' : 'Sign in'}</button>
    </form>
    {message && <p className={`feedback-message${signedIn ? ' success' : ''}`} role="status">{message}</p>}
    <p className="helper-note">Demo only: credentials are not sent to a server and this is not production authentication.</p>
  </section>;
}
