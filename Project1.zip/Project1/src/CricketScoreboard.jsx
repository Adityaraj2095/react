import { useReducer } from 'react';
import './App.css';

const initialState = { runs: 0, wickets: 0, balls: 0, history: [] };
function scoreReducer(state, action) {
  switch (action.type) {
    case 'RUNS':
      return { ...state, runs: state.runs + action.value, balls: state.balls + 1, history: [...state.history, action.value === 0 ? 'Dot ball' : `${action.value} run${action.value > 1 ? 's' : ''}`] };
    case 'WICKET':
      if (state.wickets >= 10) return state;
      return { ...state, wickets: state.wickets + 1, balls: state.balls + 1, history: [...state.history, 'Wicket'] };
    case 'EXTRA':
      return { ...state, runs: state.runs + 1, history: [...state.history, 'Wide / no-ball (+1)'] };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
}

export default function CricketScoreboard() {
  const [score, dispatch] = useReducer(scoreReducer, initialState);
  const overs = `${Math.floor(score.balls / 6)}.${score.balls % 6}`;
  const runRate = score.balls ? (score.runs / (score.balls / 6)).toFixed(2) : '0.00';
  return <section className="panel practical-panel">
    <div className="eyebrow">PRACTICAL 05 · useReducer</div>
    <h1>Cricket Score Board</h1>
    <p className="panel-description">Update the score with reducer actions. Each legal delivery or wicket advances the ball count.</p>
    <div className="scoreboard">
      <div className="score-main"><span>TEAM SCORE</span><strong>{score.runs}<small>/{score.wickets}</small></strong><p>{overs} overs <span>•</span> Run rate {runRate}</p></div>
      <div className="score-controls">
        <p>ADD RUNS</p>
        <div className="button-row score-buttons">
          {[0, 1, 2, 3, 4, 6].map(run => <button key={run} className={run === 4 || run === 6 ? 'score-btn boundary' : 'score-btn'} onClick={() => dispatch({ type: 'RUNS', value: run })}>{run === 0 ? 'Dot' : `+${run}`}</button>)}
        </div>
        <div className="button-row">
          <button className="secondary-btn" onClick={() => dispatch({ type: 'EXTRA' })}>Wide / No-ball +1</button>
          <button className="danger-btn" onClick={() => dispatch({ type: 'WICKET' })} disabled={score.wickets >= 10}>Wicket</button>
        </div>
        <button className="reset-btn" onClick={() => dispatch({ type: 'RESET' })}>Reset innings</button>
      </div>
    </div>
    <div className="list-heading"><h2>Ball-by-ball history</h2><span className="task-count">{score.history.length} events</span></div>
    {score.history.length ? <ol className="score-history">{[...score.history].reverse().map((event, i) => <li key={`${score.history.length}-${i}`}><span className="history-ball">{score.history.length - i}</span>{event}</li>)}</ol> : <div className="empty-state"><span className="empty-icon">🏏</span><strong>No deliveries yet</strong><p>Tap a scoring button to begin the innings.</p></div>}
    <p className="helper-note">Simplified practice scoreboard: extras add one run without a ball, and the Wicket button records a wicket on a delivery.</p>
  </section>;
}
